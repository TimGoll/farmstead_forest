===========================================================================
BSL Readme
===========================================================================
Join shaderLABS to get the development versions of BSL Shaders, report bugs
, share screenshots, and more.
https://discord.gg/RpzWN9S 
===========================================================================
By downloading my shader, you supported my work and i really appreciate it.
If you want to support it further, you can donate through this link:
https://www.paypal.me/capttatsu
===========================================================================
Donators :
Konnor Kiefer
Orlando Lazo
===========================================================================